
Jynx
====

Emulator for the 1983 Camputers Lynx Microcomputer, written by Jonathan Markland.

The source code can be built using Microsoft Visual Studio 2012.

Please refer to the readme.htm for installation instructions.
